# BCDBoot Repair
# Version 21.03.17
# Constants
$script:constSystemBCDStore =                  [string]::Empty
[uint32]$script:constFirmwareManager =         0x10100001
[uint32]$script:constDisplayOrderType =        0x24000001
[uint32]$script:constDisplayOrderCaptionType = 0x12000004
[uint32]$script:constWindowsBootLoader =       0x10100002

#region Functions
function Get-BCDOrder
{
    # Load the Current BCD Store
    $BcdStore = (Invoke-CimMethod -ClassName BcdStore `
                                  -Namespace root\wmi `
                                  -Arguments @{File = $constSystemBCDStore} `
                                  -MethodName OpenStore).Store

    # Validate that the BCD Store was loaded
    if($null -eq $BcdStore)
    {
        Write-Host "Could not load BCD Store. This script must be run as administrator."
        if($inTS){$tsEnv.Value("BCDCompliant") = $false}
        Exit 0
    }

    # Load the fwbootmgr BCD entry
    $fwbootmgrBCD = (Invoke-CimMethod -InputObject $BcdStore `
                                      -MethodName EnumerateObjects `
                                      -Arguments @{Type = $constFirmwareManager}).Objects

    if($fwbootmgrBCD.Count -eq 1)
    {
        $fwbootmgrBCD = $fwbootmgrBCD[0]
    }
    else
    {
        Write-Host "Something went wrong... I received multiple fwbootmgr entries..."
        if($inTS){$tsEnv.Value("BCDCheckError") = $true}
        if($inTS){$tsEnv.Value("BCDCompliant") = $false}
        Exit 0
    }

    # Load the display order element from fwbootmgr
    $displayOrderFWBCD = (Invoke-CimMethod -InputObject $fwbootmgrBCD `
                                           -MethodName GetElement `
                                           -Arguments @{Type = $constDisplayOrderType}).Element

    # Get the current display order with captions
    $displayOrderIdsWithCaption = @()
    $i = 0
    foreach($id in $displayOrderFWBCD.Ids)
    {
        $doObject = (Invoke-CimMethod -Arguments @{Id = $id} -MethodName OpenObject -InputObject $BcdStore).Object
        $caption = (Invoke-CimMethod -Arguments @{Type = $constDisplayOrderCaptionType} -MethodName GetElement -InputObject $doObject).Element.String
        $displayOrderIdsWithCaption += 
        [pscustomobject]@{
            Order = $i
            Id = $id
            Caption = $caption
        }
        $i++
    }

    return $displayOrderIdsWithCaption
}

function Get-BCDOrderStatus
{
    $displayOrderIdsWithCaption = Get-BCDOrder
    
    if((@($displayOrderIdsWithCaption.Caption) -like "*Winmagic*").Count -gt 0)
    {
        $encryptionCheck = "*Winmagic*"
    }
    elseif((@($displayOrderIdsWithCaption.Caption) -like "*Check Point*").Count -gt 0)
    {
        $encryptionCheck = "*Check Point*"
    }
    else
    {
        Write-Host "No BCD entries for encryption found on system"
        return $null
    }

    $encryptionDisplayOrder = $displayOrderIdsWithCaption | Where-Object {$_.Caption -like $encryptionCheck}
    $wbmDisplayOrder = $displayOrderIdsWithCaption | Where-Object {$_.Caption -eq "Windows Boot Manager"}

    # Determine if WBM is missing, if order is correct
    if($null -eq $wbmDisplayOrder)
    {
        # Windows Boot Manager not found - add and then move encryption to top;
        Write-Host "Windows Boot Manager not found - Error State"
        return $false
    }
    elseif($wbmDisplayOrder.Order -lt $encryptionDisplayOrder.Order)
    {
        # Windows Boot Manager above Encryption Boot Entry - fix
        Write-Host "Windows Boot Manager is a higher priority than encryption - Error State"
        return $false
    }
    else
    {
        # Everything looks good
        Write-Host "Display order is correct - Compliant State"
        return $true
    }
}

function Repair-BCDOrderStatus
{
    # Load the Current BCD Store
    $BcdStore = (Invoke-CimMethod -ClassName BcdStore `
                                  -Namespace root\wmi `
                                  -Arguments @{File = $constSystemBCDStore} `
                                  -MethodName OpenStore).Store

    # Validate that the BCD Store was loaded
    if($null -eq $BcdStore)
    {
        Write-Host "Could not load BCD Store. This script must be run as administrator."
        if($inTS){$tsEnv.Value("BCDCompliant") = $false}
        Exit 0
    }

    # Load the fwbootmgr BCD entry
    $fwbootmgrBCD = (Invoke-CimMethod -InputObject $BcdStore `
                                      -MethodName EnumerateObjects `
                                      -Arguments @{Type = $constFirmwareManager}).Objects

    if($fwbootmgrBCD.Count -eq 1)
    {
        $fwbootmgrBCD = $fwbootmgrBCD[0]
    }
    else
    {
        Write-Host "Something went wrong... I received multiple fwbootmgr entries..."
        if($inTS){$tsEnv.Value("BCDCheckError") = $true}
        if($inTS){$tsEnv.Value("BCDCompliant") = $false}
        Exit 0
    }

    $displayOrderIdsWithCaption = Get-BCDOrder

    if((@($displayOrderIdsWithCaption.Caption) -like "*Winmagic*").Count -gt 0)
    {
        $encryptionCheck = "*Winmagic*"
    }
    elseif((@($displayOrderIdsWithCaption.Caption) -like "*Check Point*").Count -gt 0)
    {
        $encryptionCheck = "*Check Point*"
    }
    else
    {
        Write-Host "No BCD entries for encryption found on system"
        return 
    }

    $encryptionDisplayOrder = $displayOrderIdsWithCaption | Where-Object {$_.Caption -like $encryptionCheck}
    $wbmDisplayOrder = $displayOrderIdsWithCaption | Where-Object {$_.Caption -eq "Windows Boot Manager"}

    # Determine if WBM is missing, if order is correct
    if($null -eq $wbmDisplayOrder)
    {
        # Windows Boot Manager not found - add and then move encryption to top;
        Write-Host "Windows Boot Manager not found - recreating"
    
        # List of Windows Boot Loaders
        $winBootLoaderList = (Invoke-CimMethod -InputObject $BcdStore -MethodName EnumerateObjects -Arguments @{Type=$constWindowsBootLoader}).Objects.Id
    
        # Find Windows Boot Manager
        foreach($wbl in $winBootLoaderList)
        {
            $wblObject = (Invoke-CimMethod -Arguments @{Id = $wbl} -MethodName OpenObject -InputObject $BcdStore).Object
            $caption = (Invoke-CimMethod -Arguments @{Type = $constDisplayOrderCaptionType} -MethodName GetElement -InputObject $wblObject).Element.String
            if($caption -eq "Windows Boot Manager")
            { 
                $displayOrderIdsWithCaption += 
                    [pscustomobject]@{
                        Order = -1
                        Id = $wbl
                        Caption = $caption
                    }
            }
        }
        if(!((@($displayOrderIdsWithCaption.Caption) -eq "Windows Boot Manager").Count -gt 0))
        {
            Write-Host "Unable to find Windows Boot Manager - something is wrong."
            return 
        }

        # Reorder the list
        ($displayOrderIdsWithCaption | Where-Object {$_.Caption -like $encryptionCheck}).Order = -2

        # Set the new displayorder
        $newDisplayOrder = ([string[]]($displayOrderIdsWithCaption | Sort-Object -Property Order).Id)
        $null = Invoke-CimMethod -InputObject $fwbootmgrBCD `
                                 -MethodName SetObjectListElement `
                                 -Arguments @{Type=$constDisplayOrderType; Ids=$newDisplayOrder}
    }
    elseif($wbmDisplayOrder.Order -lt $encryptionDisplayOrder.Order)
    {
        # Windows Boot Manager above Encryption Boot Entry - fix
        Write-Host "Windows Boot Manager is a higher priority than encryption... fixing"
    
        # Fix display order
        ($displayOrderIdsWithCaption | Where-Object {$_.Caption -like $encryptionCheck}).Order = -2

        # Set the new displayorder
        $newDisplayOrder = ([string[]]($displayOrderIdsWithCaption | Sort-Object -Property Order).Id)
        $null = Invoke-CimMethod -InputObject $fwbootmgrBCD `
                                 -MethodName SetObjectListElement `
                                 -Arguments @{Type=$constDisplayOrderType; Ids=$newDisplayOrder}
    }
    else
    {
        # Everything looks good
        Write-Host "No correction necessary - display order is correct"
        return 
    }
}
#endregion Functions

###############################################
Write-Host "--------------- Starting BCDBootFix Script -------------"
Write-Host "Initializing TS Environment"
if($tsEnv = New-Object -ComObject Microsoft.SMS.TSEnvironment){$inTS = $true}

$initialState = Get-BCDOrderStatus
if($initialState -eq $true)
{
    Write-Host "Boot Loader Validated - No Correction Necessary"
    if($inTS){$tsEnv.Value("BCDCompliant") = $initialState}
    Write-Host "Final State: $initialState"
}
elseif($initialState -eq $false)
{
    Write-Host "Correcting boot loader issue..."
    Repair-BCDOrderStatus
    Write-Host "Validating boot loader repair..."
    $finalState = Get-BCDOrderStatus
    if($inTS){$tsEnv.Value("BCDCompliant") = $finalState}
    Write-Host "Final State: $finalState"
}
Write-Host "--------------- Finished BCDBootFix Script -------------"