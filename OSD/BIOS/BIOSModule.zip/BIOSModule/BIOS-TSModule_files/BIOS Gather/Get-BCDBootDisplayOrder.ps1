Function Get-BCDBootDisplayOrder {
    

   try 
    {
    $SecureBootStatus = Confirm-SecureBootUEFI
    }
   catch {}
    if ($SecureBootStatus -eq $false -or $SecureBootStatus -eq $true)
        {
        if ((Get-WmiObject -Namespace 'root\cimv2\sms' -Query "SELECT ProductVersion FROM SMS_InstalledSoftware where ARPDisplayName like 'SecureDoc Disk%'").ProductVersion)
            {
            $FDEInstalled = $true
            }
        elseif ((Get-ItemProperty "HKLM:SOFTWARE\WOW6432Node\CheckPoint\EndPoint Security\Full Disk Encryption" -ErrorAction SilentlyContinue).UEFIInstallationMode)
            {
            $FDEInstalled = $true
            }
        }
    else
        {
        #Not UEFI
        }

    if ($FDEInstalled)
        {
            # Constants
            $constSystemBCDStore =                  [string]::Empty
            [uint32]$constFirmwareManager =         0x10100001
            [uint32]$constDisplayOrderType =        0x24000001
            [uint32]$constDisplayOrderCaptionType = 0x12000004
            [uint32]$constWindowsBootLoader =       0x10100002

            # Load the Current BCD Store
            $BcdStore = (Invoke-CimMethod -ClassName BcdStore `
                                          -Namespace root\wmi `
                                          -Arguments @{File = $constSystemBCDStore} `
                                          -MethodName OpenStore).Store

            # Validate that the BCD Store was loaded
            if($null -eq $BcdStore)
            {
                return "ERROR - Could not load BCD Store"
            }

            # Load the fwbootmgr BCD entry
            $fwbootmgrBCD = (Invoke-CimMethod -InputObject $BcdStore `
                                              -MethodName EnumerateObjects `
                                              -Arguments @{Type = $constFirmwareManager}).Objects
            if($fwbootmgrBCD.Count -eq 1)
            {
                $fwbootmgrBCD = $fwbootmgrBCD[0]
            }
            else
            {
                return "ERROR - Multiple Firmware Boot Entries"
            }

            # Load the display order element from fwbootmgr
            $displayOrderFWBCD = (Invoke-CimMethod -InputObject $fwbootmgrBCD `
                                                   -MethodName GetElement `
                                                   -Arguments @{Type = $constDisplayOrderType}).Element

            # Get the current display order with captions
            $displayOrderIdsWithCaption = @()
            $i = 0
            foreach($id in $displayOrderFWBCD.Ids)
            {
                $doObject = (Invoke-CimMethod -Arguments @{Id = $id} -MethodName OpenObject -InputObject $BcdStore).Object
                $caption = (Invoke-CimMethod -Arguments @{Type = $constDisplayOrderCaptionType} -MethodName GetElement -InputObject $doObject).Element.String
                $displayOrderIdsWithCaption += 
                [pscustomobject]@{
                    Order = $i
                    Id = $id
                    Caption = $caption
                }
                $i++
            }

            if((@($displayOrderIdsWithCaption.Caption) -like "*Winmagic*").Count -gt 0)
            {
                $encryptionCheck = "*Winmagic*"
            }
            elseif((@($displayOrderIdsWithCaption.Caption) -like "*Check Point*").Count -gt 0)
            {
                $encryptionCheck = "*Check Point*"
            }
            else
            {
                # Device doesn't have encryption
                return "Compliant - No Encryption Loader Found"
            }

            $encryptionDisplayOrder = $displayOrderIdsWithCaption | Where-Object {$_.Caption -like $encryptionCheck}
            $wbmDisplayOrder = $displayOrderIdsWithCaption | Where-Object {$_.Caption -eq "Windows Boot Manager"}

            # Determine if WBM is missing, if order is correct
            if($null -eq $wbmDisplayOrder)
            {
                return "FAIL - {bootmgr} entry not found."
            }
            elseif($wbmDisplayOrder.Order -lt $encryptionDisplayOrder.Order)
            {
                return "FAIL - Display order is incorrect."
            }
            else
            {
                return "Compliant - Display Order is Correct"
            }
        }



}

$Results = Get-BCDBootDisplayOrder
if ($Results)
    {
    if ($Results -match "Compliant")
        {Write-Output "TRUE"}
    else
        {$Results}
    
    }
else
    {
    Write-Output "TRUE"
    }
