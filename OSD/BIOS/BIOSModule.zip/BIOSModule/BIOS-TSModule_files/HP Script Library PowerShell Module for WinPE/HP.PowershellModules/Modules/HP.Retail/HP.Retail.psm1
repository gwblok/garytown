# 
#  Copyright 2018-2021 HP Development Company, L.P.
#  All Rights Reserved.
# 
# NOTICE:  All information contained herein is, and remains the property of HP Development Company, L.P.
# 
# The intellectual and technical concepts contained herein are proprietary to HP Development Company, L.P
# and may be covered by U.S. and Foreign Patents, patents in process, and are protected by 
# trade secret or copyright law. Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained from HP Development Company, L.P.



Set-StrictMode -Version 5.1
#requires -Modules "HP.Private", "HP.Firmware"


enum RetailDockStatus{
  NotDocked = 0
  Docked = 1
  Jammed = 2
  Unknown = 0xff
}


enum RetailHubType{
  NotPresent = 0
  AdvancedConnectivityBase = 1
  BasicConnectivityBase = 2
  Unknown = 0xff
}


enum RetailDockMode{
  FastRelease = 0
  FastReleaseAndPIN = 1
  Privileged = 2
  PrivilegedAndPIN = 3
  Application = 4
  Unknown = 0xff
}


<#
.SYNOPSIS
    Retrieve information about an HP retail system

.DESCRIPTION
  Thus function retrieves information about an HP Retail system such as the HP Engage.


.PARAMETER ShowPin
  Include the PIN in output


.EXAMPLE
    Get-HPRetailSmartDockConfiguration -ShowPin


.NOTES
  - This function requires elevated privileges.
    - This is a special purpose function that will only execute successfully in the presence of supported hardware.

#>
function Get-HPRetailSmartDockConfiguration {
  [CmdletBinding(HelpUri = "https://developers.hp.com/hp-client-management/doc/Get%E2%80%90HPRetailSmartDockConfiguration")]
  param(
    [switch]$ShowPin
  )

  [RetailInformation]$c = Get-HPPrivateRetailConfiguration
  $configuration = [ordered]@{
    RetailSmartDockSupported = $false
  }
  if ($c.IsSupported) {

    Write-Verbose 'Firmware supports retail smart dock'
    $configuration.RetailSmartDockSupported = $true
    $configuration.Add("RetailSmartDockMode",[RetailDockMode]$c.Mode)
    $configuration.Add("RetailSmartDockTimeoutSeconds",$c.Timeout) # what is 'timeout' ?
    $configuration.Add("RetailSmartDockState",[RetailDockStatus]$c.DockState)
    $configuration.Add("RetailSmartDockHub",[RetailHubType]$c.HubState)
    $configuration.Add("RetailSmartDockDockCounter",$c.DockCounter)
    #$configuration.Add("RetailSmartDockUndockCounter",$c.UndockCounter)
    $configuration.Add("RetailSmartDockBaseLockoutSeconds",$c.BaseLockoutTimer)
    $configuration.Add("RetailSmartDockRelockSeconds",$c.RelockTimer)


    if ($c.PinSize) {
      $configuration.PinIsSet = $true

      if ($ShowPin.IsPresent) {
        $configuration.Add("ActivePIN",[System.Text.Encoding]::UTF8.GetString($c.Pin).trim())

      }
    }
    else {
      $configuration.PinIsSet = $false
    }

  }
  else {
    Write-Verbose 'Firmware does not support retail smart dock'
  }
  $configuration
}


<#
.SYNOPSIS
  Configures an HP Engage Retail System

.DESCRIPTION
  Thus function configures the settings of an HP Retail system such as the HP Engage Go.

.PARAMETER Mode
  The mode to activate. Supported modes are:

    - "FastRelease": No authentication required. Simply unlock the table with the touch of a button
    - "FastReleaseAndPIN": A PIN is required to unlock the table
    - "Privileged": Only privileged users can unlock the tablet
    - "PrivilegedAndPIN": Only privileged users with PIN can unlock the tablet
    - "Application": TODO

.PARAMETER PIN
  The PIN to set, which must be a numeric string between 4 and 10 characters. This property is mandatory for "FastReleaseAndPIN" and "PrivilegedAndPIN", and must not be supplied for other modes.

.PARAMETER PINData
  SecureString PINData to use

.PARAMETER BaseLockoutTime
  Set the base lockout time, in seconds. This must be a value between 30 and 1800 seconds.

.PARAMETER RelockTime
  Set the relock time, in seconds. This must be a value between 10 and 300 seconds.


.EXAMPLE
  Set-HPRetailSmartDockConfiguration -Mode PrivilegedAndPIN -PIN 123456

.NOTES
 - This function requires elevated privileges.
 - This is a special purpose function that will only execute successfully in the presence of supported hardware.

#>

function Set-HPRetailSmartDockConfiguration {
  [CmdletBinding(HelpUri = "https://developers.hp.com/hp-client-management/doc/Set%E2%80%90HPRetailSmartDockConfiguration")]
  param(
    [Parameter(ParameterSetName = 'Mode',Position = 0,Mandatory = $true)]
    [Parameter(ParameterSetName = 'ModePin',Position = 0,Mandatory = $true)]
    [Parameter(ParameterSetName = 'ModeSPin',Position = 0,Mandatory = $true)]
    [ValidateSet('FastRelease','FastReleaseAndPIN','Privileged','PrivilegedAndPIN','Application')]
    [RetailDockMode]$Mode = 'Unknown',


    [Parameter(ParameterSetName = 'ModePin',Position = 1,Mandatory = $true)]
    [ValidatePattern("^\d*$")]
    [ValidateLength(4,10)]
    [string]$PIN,

    [Parameter(ParameterSetName = 'ModeSPin',Position = 1,Mandatory = $true)]
    [securestring]$PINData,


    [Parameter(ParameterSetName = 'All',Position = 2,Mandatory = $false)]
    [Parameter(ParameterSetName = 'Mode',Position = 2,Mandatory = $false)]
    [Parameter(ParameterSetName = 'ModePin',Position = 2,Mandatory = $false)]
    [Parameter(ParameterSetName = 'ModeSPin',Position = 2,Mandatory = $false)]
    [ValidatePattern("^\d*$")]
    [ValidateRange(30,1800)]
    [int]$BaseLockoutTime = 0,

    [Parameter(ParameterSetName = 'All',Position = 3,Mandatory = $false)]
    [Parameter(ParameterSetName = 'Mode',Position = 3,Mandatory = $false)]
    [Parameter(ParameterSetName = 'ModePin',Position = 3,Mandatory = $false)]
    [Parameter(ParameterSetName = 'ModeSPin',Position = 3,Mandatory = $false)]
    [ValidatePattern("^\d*$")]
    [ValidateRange(10,300)]
    [int]$RelockTime = 0

  )
  if (($Mode -eq "Unknown") -and (-not $BaseLockoutTime) -and (-not $RelockTime)) {

    Write-Verbose "Nothing to do."
    return
  }
  [RetailInformation]$r = Get-HPPrivateRetailConfiguration -Verbose:$VerbosePreference

  if ($r -and $r.IsSupported) {
    if ($Mode -eq "FastRelease" -or $Mode -eq "Privileged") {
      Write-Verbose "Handling docking mode $Mode (this mode doesn't require PIN)"
      if ($Pin -or $PINData) {
        Write-Verbose "PIN Specified for mode '$Mode' which does not accept a PIN"
        throw [ArgumentException]"PIN or PINData is not valid for this mode."
      }
      $r.PinSize = 0
      $r.Pin = @(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
    }


    if ($mode -eq "FastReleaseAndPIN" -or $mode -eq "PrivilegedAndPIN" -or $mode -eq "Application") {
      Write-Verbose "Handling docking mode $Mode (this mode requires PIN)"
      if (-not $Pin -and -not $PinData) {
        Write-Verbose "PIN not specified for mode '$Mode' which requires a PIN"
        throw [ArgumentException]"PIN or PINData may not be null for this mode."
      }
      if ($PinData) {
        Write-Verbose 'Using SecureString PIN'
        $pin = (New-Object System.Net.NetworkCredential -ArgumentList "",$PinData).Password
        if (($pin.Length -lt 4) -or ($pin.Length -gt 10)) {
          throw [ArgumentException]("PIN must be between 4 and 10 characters in length.")

        }
        if (-not $pin -match "^\d*$") {
          throw [ArgumentException]("PIN can only contain characters 0 through 9")
        }
      }
      else {
        Write-Verbose 'Using plain test PIN'
      }

      if ($Pin -or $PinData) {
        $pinbytes = ([System.Text.Encoding]::UTF8.GetBytes($Pin) | ForEach-Object { $_ - 0x30 })
        $padding = New-Object byte[] (16 - $pinbytes.Length)
        $r.Pin = $pinbytes + $padding
        $r.PinSize = $Pin.Length
      }
    }

    $r.Mode = $Mode
    if (-not $pin -and -not $pindata) {
      $r.Pin = $r.Pin | ForEach-Object { if ($_ -ge 0x30) { $_ - 0x30 } else { $_ } }
    }
    if ($BaseLockoutTime) {
      Write-Verbose "Setting BaseLockoutTimer to $BaseLockoutTime seconds"
      $r.BaseLockoutTimer = $BaseLockoutTime
    }

    if ($RelockTime) {
      Write-Verbose "Setting RelockTimer to $RelockTime seconds"
      $r.RelockTimer = $RelockTime
    }

    Set-HPPrivateRetailConfiguration -configuration $r
  }
  else {
    throw [NotSupportedException]"This platform does not support HP Retail Smart Dock"
  }
}



# SIG # Begin signature block
# MIIaywYJKoZIhvcNAQcCoIIavDCCGrgCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDrKzGBrxwFnai3
# M4ssJPvJMBdmpvMBESyToGI/dcxOYqCCCm8wggUwMIIEGKADAgECAhAECRgbX9W7
# ZnVTQ7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBa
# Fw0yODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lD
# ZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/l
# qJ3bMtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fT
# eyOU5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqH
# CN8M9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+
# bMt+dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLo
# LFH3c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIB
# yTASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAK
# BggrBgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHow
# eDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJl
# ZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwA
# AgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAK
# BghghkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7s
# DVoks/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGS
# dQ9RtG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6
# r7VRwo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo
# +MUSaJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qz
# sIzV6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHq
# aGxEMrJmoecYpJpkUe8wggU3MIIEH6ADAgECAhAFUi3UAAgCGeslOwtVg52XMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcNMjEwMzIyMDAwMDAw
# WhcNMjIwMzMwMjM1OTU5WjB1MQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZv
# cm5pYTESMBAGA1UEBxMJUGFsbyBBbHRvMRAwDgYDVQQKEwdIUCBJbmMuMRkwFwYD
# VQQLExBIUCBDeWJlcnNlY3VyaXR5MRAwDgYDVQQDEwdIUCBJbmMuMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtJ+rYUkseHcrB2M/GyomCEyKn9tCyfb+
# pByq/Jyf5kd3BGh+/ULRY7eWmR2cjXHa3qBAEHQQ1R7sX85kZ5sl2ukINGZv5jEM
# 04ERNfPoO9+pDndLWnaGYxxZP9Y+Icla09VqE/jfunhpLYMgb2CuTJkY2tT2isWM
# EMrKtKPKR5v6sfhsW6WOTtZZK+7dQ9aVrDqaIu+wQm/v4hjBYtqgrXT4cNZSPfcj
# 8W/d7lFgF/UvUnZaLU5Z/+lYbPf+449tx+raR6GD1WJBAzHcOpV6tDOI5tQcwHTo
# jJklvqBkPbL+XuS04IUK/Zqgh32YZvDnDohg0AEGilrKNiMes5wuAQIDAQABo4IB
# xDCCAcAwHwYDVR0jBBgwFoAUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHQYDVR0OBBYE
# FD4tECf7wE2l8kA6HTvOgkbo33MvMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAK
# BggrBgEFBQcDAzB3BgNVHR8EcDBuMDWgM6Axhi9odHRwOi8vY3JsMy5kaWdpY2Vy
# dC5jb20vc2hhMi1hc3N1cmVkLWNzLWcxLmNybDA1oDOgMYYvaHR0cDovL2NybDQu
# ZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC1jcy1nMS5jcmwwSwYDVR0gBEQwQjA2
# BglghkgBhv1sAwEwKTAnBggrBgEFBQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5j
# b20vQ1BTMAgGBmeBDAEEATCBhAYIKwYBBQUHAQEEeDB2MCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wTgYIKwYBBQUHMAKGQmh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFNIQTJBc3N1cmVkSURDb2RlU2lnbmlu
# Z0NBLmNydDAMBgNVHRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4IBAQBZca1CZfgn
# DucOwEDZk0RXqb8ECXukFiih/rPQ+T5Xvl3bZppGgPnyMyQXXC0fb94p1socJzJZ
# fn7rEQ4tHxL1vpBvCepB3Jq+i3A8nnJFHSjY7aujglIphfGND97U8OUJKt2jwnni
# EgsWZnFHRI9alEvfGEFyFrAuSo+uBz5oyZeOAF0lRqaRht6MtGTma4AEgq6Mk/iP
# LYIIZ5hXmsGYWtIPyM8Yjf//kLNPRn2WeUFROlboU6EH4ZC0rLTMbSK5DV+xL/e8
# cRfWL76gd/qj7OzyJR7EsRPg92RQUC4RJhCrQqFFnmI/K84lPyHRgoctAMb8ie/4
# X6KaoyX0Z93PMYIPsjCCD64CAQEwgYYwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoT
# DERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UE
# AxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIENvZGUgU2lnbmluZyBDQQIQBVIt
# 1AAIAhnrJTsLVYOdlzANBglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwxAjAA
# MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
# BgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCA/jLQUIjMaq8T4v3qUwvyxeTB86zZi
# ItTrwKtF5K97MjANBgkqhkiG9w0BAQEFAASCAQApOq73RlpqUBkNDGWYlDbO2jRL
# Qe+zpfHkIovAIaEjB8VRkKPpL1zKxGi7kWePn8PzwarW1ja3/QVn+2vpOgRGmdG4
# 0Nw/jIgpe6u5DzP9HkhdZI/EY9cHVtBYLxRPd+yn9Q9vy8YQBONqim2PPvhS8T/+
# L4rw3caTF7NoV5ySt6VFgLYPwh1BJF4eQtEOkHbwIA8p1lKNwJPiAQfcrEVO7BjE
# lyuQsPJ1fV6TQBgmhlkz01lbIdOdEO9iGA1Pz1hFSgoh2YbgYHhyfFQo+6E8GflL
# c5+Btb8mLdzt/b6pQ6wunDt993/Feqh52nH5XzKnt77d8xU9unQGyHXGHgGzoYIN
# fjCCDXoGCisGAQQBgjcDAwExgg1qMIINZgYJKoZIhvcNAQcCoIINVzCCDVMCAQMx
# DzANBglghkgBZQMEAgEFADB4BgsqhkiG9w0BCRABBKBpBGcwZQIBAQYJYIZIAYb9
# bAcBMDEwDQYJYIZIAWUDBAIBBQAEIHbLTQTVzFaLIU8XNzTDWs7ZLmkeZXoeOtzO
# VThde8TnAhEA75TSUIqNoRu9WQ3GJUY36xgPMjAyMTExMjIxOTE5MDNaoIIKNzCC
# BP4wggPmoAMCAQICEA1CSuC+Ooj/YEAhzhQA8N0wDQYJKoZIhvcNAQELBQAwcjEL
# MAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3
# LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElE
# IFRpbWVzdGFtcGluZyBDQTAeFw0yMTAxMDEwMDAwMDBaFw0zMTAxMDYwMDAwMDBa
# MEgxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjEgMB4GA1UE
# AxMXRGlnaUNlcnQgVGltZXN0YW1wIDIwMjEwggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDC5mGEZ8WK9Q0IpEXKY2tR1zoRQr0KdXVNlLQMULUmEP4dyG+R
# awyW5xpcSO9E5b+bYc0VkWJauP9nC5xj/TZqgfop+N0rcIXeAhjzeG28ffnHbQk9
# vmp2h+mKvfiEXR52yeTGdnY6U9HR01o2j8aj4S8bOrdh1nPsTm0zinxdRS1LsVDm
# QTo3VobckyON91Al6GTm3dOPL1e1hyDrDo4s1SPa9E14RuMDgzEpSlwMMYpKjIjF
# 9zBa+RSvFV9sQ0kJ/SYjU/aNY+gaq1uxHTDCm2mCtNv8VlS8H6GHq756WwogL0sJ
# yZWnjbL61mOLTqVyHO6fegFz+BnW/g1JhL0BAgMBAAGjggG4MIIBtDAOBgNVHQ8B
# Af8EBAMCB4AwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDBB
# BgNVHSAEOjA4MDYGCWCGSAGG/WwHATApMCcGCCsGAQUFBwIBFhtodHRwOi8vd3d3
# LmRpZ2ljZXJ0LmNvbS9DUFMwHwYDVR0jBBgwFoAU9LbhIB3+Ka7S5GGlsqIlssgX
# NW4wHQYDVR0OBBYEFDZEho6kurBmvrwoLR1ENt3janq8MHEGA1UdHwRqMGgwMqAw
# oC6GLGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQtdHMuY3Js
# MDKgMKAuhixodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVkLXRz
# LmNybDCBhQYIKwYBBQUHAQEEeTB3MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5k
# aWdpY2VydC5jb20wTwYIKwYBBQUHMAKGQ2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0
# LmNvbS9EaWdpQ2VydFNIQTJBc3N1cmVkSURUaW1lc3RhbXBpbmdDQS5jcnQwDQYJ
# KoZIhvcNAQELBQADggEBAEgc3LXpmiO85xrnIA6OZ0b9QnJRdAojR6OrktIlxHBZ
# vhSg5SeBpU0UFRkHefDRBMOG2Tu9/kQCZk3taaQP9rhwz2Lo9VFKeHk2eie38+dS
# n5On7UOee+e03UEiifuHokYDTvz0/rdkd2NfI1Jpg4L6GlPtkMyNoRdzDfTzZTlw
# S/Oc1np72gy8PTLQG8v1Yfx1CAB2vIEO+MDhXM/EEXLnG2RJ2CKadRVC9S0yOIHa
# 9GCiurRS+1zgYSQlT7LfySmoc0NR2r1j1h9bm/cuG08THfdKDXF+l7f0P4TrweOj
# SaH6zqe/Vs+6WXZhiV9+p7SOZ3j5NpjhyyjaW4emii8wggUxMIIEGaADAgECAhAK
# oSXW1jIbfkHkBdo2l8IVMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUw
# EwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20x
# JDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xNjAxMDcx
# MjAwMDBaFw0zMTAxMDcxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxE
# aWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMT
# KERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcgQ0EwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC90DLuS82Pf92puoKZxTlUKFe2I0rE
# DgdFM1EQfdD5fU1ofue2oPSNs4jkl79jIZCYvxO8V9PD4X4I1moUADj3Lh477sym
# 9jJZ/l9lP+Cb6+NGRwYaVX4LJ37AovWg4N4iPw7/fpX786O6Ij4YrBHk8JkDbTuF
# fAnT7l3ImgtU46gJcWvgzyIQD3XPcXJOCq3fQDpct1HhoXkUxk0kIzBdvOw8YGqs
# LwfM/fDqR9mIUF79Zm5WYScpiYRR5oLnRlD9lCosp+R1PrqYD4R/nzEU1q3V8mTL
# ex4F0IQZchfxFwbvPc3WTe8GQv2iUypPhR3EHTyvz9qsEPXdrKzpVv+TAgMBAAGj
# ggHOMIIByjAdBgNVHQ4EFgQU9LbhIB3+Ka7S5GGlsqIlssgXNW4wHwYDVR0jBBgw
# FoAUReuir/SSy4IxLVGLp6chnfNtyA8wEgYDVR0TAQH/BAgwBgEB/wIBADAOBgNV
# HQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwgYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6
# Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmww
# UAYDVR0gBEkwRzA4BgpghkgBhv1sAAIEMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8v
# d3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCwYJYIZIAYb9bAcBMA0GCSqGSIb3DQEBCwUA
# A4IBAQBxlRLpUYdWac3v3dp8qmN6s3jPBjdAhO9LhL/KzwMC/cWnww4gQiyvd/Mr
# HwwhWiq3BTQdaq6Z+CeiZr8JqmDfdqQ6kw/4stHYfBli6F6CJR7Euhx7LCHi1lss
# FDVDBGiy23UC4HLHmNY8ZOUfSBAYX4k4YU1iRiSHY4yRUiyvKYnleB/WCxSlgNcS
# R3CzddWThZN+tpJn+1Nhiaj1a5bA9FhpDXzIAbG5KHW3mWOFIoxhynmUfln8jA/j
# b7UBJrZspe6HUSHkWGCbugwtK22ixH67xCUrRwIIfEmuE7bhfEJCKMYYVs9BNLZm
# XbZ0e/VWMyIvIjayS6JKldj1po5SMYIChjCCAoICAQEwgYYwcjELMAkGA1UEBhMC
# VVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0
# LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIFRpbWVzdGFt
# cGluZyBDQQIQDUJK4L46iP9gQCHOFADw3TANBglghkgBZQMEAgEFAKCB0TAaBgkq
# hkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcNAQkFMQ8XDTIxMTEyMjE5
# MTkwM1owKwYLKoZIhvcNAQkQAgwxHDAaMBgwFgQU4deCqOGRvu9ryhaRtaq0lKYk
# m/MwLwYJKoZIhvcNAQkEMSIEILlTCnP+Nzue6H993U6dXhzZf9eUrApXgF1zerQ4
# KJp/MDcGCyqGSIb3DQEJEAIvMSgwJjAkMCIEILMQkAa8CtmDB5FXKeBEA0Fcg+Mp
# K2FPJpZMjTVx7PWpMA0GCSqGSIb3DQEBAQUABIIBAGs1GVaMPNzL+E6InRDWSbIQ
# IUwBjswaFymKFo4joCwfgNb4gVVtNE73+znvHWYMi1AyUPYlUo1JEoDUek7hDYMh
# 8AdRVNxUIf44EjHDYMxF8UIgSYHIerqRkJ5ADxLNstVuiM9p3cqjwaqlEg+MNEd/
# 3Y2CrRrFw9dgWZkmIJTIWYpAX0EurY45gwADkwnLf+pcuD5cxWVQ21do2iO2Kb3n
# Hy29z1kk45M2nIyPA5Osmds2U6vYXlTlSZIAZqYA7BiKfExjwiuUPTYJaTOItOm2
# cPUWmmq/NhX5kmHJW9gwzTdjN/qdf8lC3/6YwBPF4g1W9mIDKu6lhTqrpMHvlqs=
# SIG # End signature block
