#  Copyright (C)2018 HP Inc
#  All Rights Reserved.
# 
# NOTICE:  All information contained herein is, and remains the property of HP Inc.
# 
# The intellectual and technical concepts contained herein are proprietary to HP Inc
# and may be covered by U.S. and Foreign Patents, patents in process, and are protected by 
# trade secret or copyright law. Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained from HP Inc.




<#
.SYNOPSIS

	Command line interface to perform various HP BIOS operations

.DESCRIPTION

	This script is a user-facing command line interface for manipulating HPBIOS settings. It can be used
	to set, read, or reset BIOS settings.

	The script supports input and output formats in XML, JSON, CSV, and also in the legacy Bios Configuration Utility (BCU) format.
	Normally the file format is inferred from the extension of the file, but can also be dictated via the -format parameter.



.PARAMETER get

	format: \<-get\> <setting> [-format <csv|bcu|json|xml>]

	Get a single setting from the BIOS. By default, the only setting's value is returned.

	Optionally, the -format string may be provided to retrieve a full setting definition, and format it as a bcu, xml, json, or csv entry.

  
.PARAMETER set

	format: \<-set\> <setting> [-value] \<newvalue\> [-currentpassword \<password\>]

	Set a single bios setting. Specify the value with the -value switch
	If a BIOS setup passwod is currently active on the machine, the password must be supplied via the -currentpassword switch


.PARAMETER password

	format: \<-password\> <-set \<password\> |-check | -clear> [-currentpassword \<password\>] 

	Manipulates the setup password. 

	Specify -set <password> to set the password, -check to check if the password is set, and -clear to clear the password.

	To modify the password while a password is already set, the existing password must be supplied via the -currentpassword argument.

.PARAMETER import

	format: \<-import\> <file> [-format <csv|bcu|json|xml>] [-nosummary] [-nowarnings] [-currentpassword \<password\>]

	Import one or more settings from a file. Normally the format of the file is inferred from the file extension, but can be overriden
	with the -format parameter.

	Specify -nosummary to turn off the end-import one-line summary. By default, -nosummary is false.

	Specify -nowarnings to turn off any warnings about settings that are not found. By default, -nowarnings is false.

	If a setup password is active on the system, it must be specified via the -currentpassword switch.

.PARAMETER export

	format: \<-export\> <file> [-format <csv|bcu|json|xml>]

	Export one or more settings to a file. Normally the format of the file is inferred from the file extension, but can be overriden
	with the -format parameter. Password settings are not exported.

.PARAMETER reset

	format: \<-reset\>  [-currentpassword \<password\>]

	Reset all settings to factory defaults. The result of this operation may be platform specific.

	If a setup password is active on the system, it must be specified via the -currentpassword switch.

.PARAMETER help

	format: \<-help\> 

	Print the command line usage.


.NOTES

	Where passwords are required, they may be specified as a single dash (-). This will cause the script to promt the user for the password.
	Use this when passing passwords via the command line is inappropriate.


.INPUTS
	For -import, read access to the specified file is expected.
	If a setup password is active on the machine, the setup password is a required input for modifying settings.

.OUTPUTS
	For -export, write access to the specified file is expected.

.EXAMPLE 

	Setting BIOS Settings
	
		bios-cli.ps1 -set "Asset Tracking Number" -value "My Tag"

.EXAMPLE 

	Getting a BIOS setting
	
		bios-cli.ps1 -get "Asset Tracking Number"

		bios-cli.ps1 -get "Asset Tracking Number" -format json
		

.EXAMPLE 

	Exporting all settings
	
		bios-cli.ps1 -export test.json

		bios-cli.ps1 -export test.txt -format bcu

		bios-cli.ps1 -export test.txt -currentpassword mycurrentpassword

	The following version is identical to previous version, but prompts for password

		bios-cli.ps1 -export test.txt -currentpassword -


.EXAMPLE 

	Exporting all settings
	
		bios-cli.ps1 -export test.json

		bios-cli.ps1 -export test.txt -format bcu


.EXAMPLE 

	Importing settings
	
		bios-cli.ps1 -import test.bcu

		bios-cli.ps1 -import test.txt -nowarnings -nosummary -format bcu

		bios-cli.ps1 -import test.json -currentpassword mypassword

	The following version is identical to previous version, but prompts for password

		bios-cli.ps1 -import test.json -currentpassword -

.EXAMPLE 

	Resetting settings
	
		bios-cli.ps1 -reset

.EXAMPLE 

	Check if BIOS setup password is set

		bios-cli -password -check

	Clear current password

		bios-cli -password -clear -currentpassword oldpassword

		or to prompt for password...

		bios-cli -password -clear -currentpassword -

	Set / Change password

		bios-cli -password -set newpassword -currentpassword oldpassword

		or to prompt for both password...

		bios-cli -password -set -  -currentpassword -


#>



#
# bios-cli.ps1
#
#requires -version 3
[CmdletBinding(DefaultParameterSetName = 'help')]
param(

  [string]
  [Parameter(ParameterSetName = 'import',Position = 0,Mandatory = $true)]
  $import,
  [string]
  [Parameter(ParameterSetName = 'export',Position = 0,Mandatory = $true)]
  $export,
  [switch]
  [Parameter(ParameterSetName = 'help',Position = 0,Mandatory = $false)]
  $help,
  [string]
  [Parameter(ParameterSetName = 'get',Position = 0,Mandatory = $true)]
  $get,
  [switch]
  [Parameter(ParameterSetName = 'reset',Position = 0,Mandatory = $true)]
  $reset,
  [switch]
  [Parameter(ParameterSetName = 'password',Position = 0,Mandatory = $true)]
  $password,
  [string]
  [Parameter(ParameterSetName = 'set',Position = 0,Mandatory = $true)]
  [Parameter(ParameterSetName = 'password',Position = 1,Mandatory = $false)]
  $set,
  [string]
  [Parameter(ParameterSetName = 'set',Position = 1,Mandatory = $true)]
  $value,
  [switch]
  [Parameter(ParameterSetName = 'password',Position = 1,Mandatory = $false)]
  $clear,
  [switch]
  [Parameter(ParameterSetName = 'password',Position = 1,Mandatory = $false)]
  $check,
  [string]
  [Parameter(Mandatory = $false,ParameterSetName = 'export',Position = 2)]
  [Parameter(Mandatory = $false,ParameterSetName = 'get',Position = 2)]
  [Parameter(Mandatory = $false,ParameterSetName = 'import',Position = 2)]
  [ValidateSet('bcu','csv','xml','json',"brief")]
  $format,
  [string]
  [Parameter(ParameterSetName = 'password',Mandatory = $false,Position = 3)]
  [Parameter(ParameterSetName = 'set',Mandatory = $false,Position = 3)]
  [Parameter(ParameterSetName = 'reset',Mandatory = $false,Position = 3)]
  [Parameter(ParameterSetName = 'import',Mandatory = $false,Position = 3)]
  $currentpassword = "",
  [switch]
  [Parameter(ParameterSetName = 'import',Position = 4,Mandatory = $false)]
  $nosummary,
  [switch]
  [Parameter(ParameterSetName = 'import',Position = 5,Mandatory = $false)]
  $nowarnings,
  [string]
  [Parameter(ParameterSetName = 'password',Mandatory = $false,Position = 6)]
  [Parameter(ParameterSetName = 'get',Mandatory = $false,Position = 6)]
  [Parameter(ParameterSetName = 'set',Mandatory = $false,Position = 6)]
  [Parameter(ParameterSetName = 'reset',Mandatory = $false,Position = 6)]
  [Parameter(ParameterSetName = 'import',Mandatory = $false,Position = 6)]
  [Parameter(ParameterSetName = 'export',Mandatory = $false,Position = 6)]
  $target = "."
)

if ($args) { Write-Warning "Unknown arguments: $args" }

if ($currentpassword -eq "-") {
  $currentpassword = $(Read-Host "Current BIOS password")
}

# print out the cmdlet help
function do-help ()
{
  Write-Host "HP BIOS Command Line Interface"
  Write-Host "Copyright (C) 2018 HP Development Company, L.P."
  Write-Host "----------------------------------------------"
  Write-Host "bios-cli -help"
  Write-Host "         - print this help text"
  Write-Host ""
  Write-Host "bios-cli -export <file> [-format bcu|json|xml|csv|brief] -target [computer]"
  Write-Host "         - exports all BIOS settings to a file, using specified format.  Specify bcu (default) for"
  Write-Host "           BiosConfigurationUtility compatibility, xml for HPIA XML format, or CSV for a simple"
  Write-Host "           comma-separated-values format. Default is determined from file extension, or 'brief' "
  Write-Host "           if an extension is unknown. Brief will export just the setting names (no values) "
  Write-Host ""
  Write-Host "bios-cli -import <file> [-format bcu|json|xml|csv] [-currentpassword password] [-nosummary] [-nowarnings] -target [computer]"
  Write-Host "         - imports all BIOS settings to a file, using specified format.  If the format"
  Write-Host "           is not specified, it's inferred from the file extension, defaulting to 'bcu'"
  Write-Host ""
  Write-Host "bios-cli -get <setting_name> [-format bcu|json|xml|csv] -target [computer]"
  Write-Host "         - print out the value of the specified BIOS setting. Optionally specifiy a formatting"
  Write-Host "          to get a full representation of the setting in the desired format."
  Write-Host ""
  Write-Host "bios-cli -set <setting_name> -value <setting_value> [-currentpassword password] -target [computer]"
  Write-Host "         - set the specified BIOS setting to the provided value"
  Write-Host ""
  Write-Host "bios-cli -password -set <password> [-currentpassword <str>] -target [computer]"
  Write-Host "         - change or set the BIOS password to the specified value"
  Write-Host ""
  Write-Host "bios-cli -password -clear -currentpassword <str> -target [computer]"
  Write-Host "         - clear the BIOS password"
  Write-Host ""
  Write-Host "bios-cli -password -check -target [computer]"
  Write-Host "         - check if a BIOS setup password is currently set"
  Write-Host ""
  Write-Host "bios-cli -reset [-currentpassword <str>] -target [computer]"
  Write-Host "         - reset all BIOS settings to default."
  Write-Host ""
  Write-Host "* passwords may be specified as - (dash) to instruct the script to prompt for the password"
}

function Do-Password ()
{
  [CmdletBinding()]
  param()

  try {
    switch ($true)
    {
      { $_ -eq $check } {
        $c = Get-HPBIOSSetupPasswordIsSet -target $target -Verbose:$VerbosePreference
        return $c
      }

      { $_ -eq $clear } {
        $c = Clear-HPBIOSSetupPassword -password $currentpassword -target $target -Verbose:$VerbosePreference
        return $c
      }

      { ($_ -eq $set) } {
        if ($set -eq "-") {
          $set = $(Read-Host "New BIOS password")
        }

        $c = Set-HPBIOSSetupPassword -newPassword $set -password $currentpassword -target $target -Verbose:$VerbosePreference
        return $c

      }
      { (($_ -eq $clear) -and ($currentpassword)) } {
        $c = Clear-HPBIOSSetupPassword -password $currentpassword -target $target -Verbose:$VerbosePreference
        return $c
      }

      default { do-help }
    }
  }
  catch {
    Write-Host -ForegroundColor Magenta "$($PSItem.ToString())"
  }

}


function Do-Reset ()
{
  [CmdletBinding()]
  param()

  try {
    return Set-HPBIOSSettingDefaults ($currentpassword) -target $target -Verbose:$VerbosePreference
  }
  catch {
    Write-Host -ForegroundColor Magenta "$($PSItem.ToString())"
  }
}


function Do-Set ()
{
  [CmdletBinding()]
  param()

  try {
    return Set-HPBIOSSettingValue -Name $set -Value $value -password $currentpassword -target $target -Verbose:$VerbosePreference
  }
  catch {
    Write-Host -ForegroundColor Magenta "$($PSItem.ToString())"
  }
}

function Do-Get ()
{
  [CmdletBinding()]
  param()

  try {
    if (($format -eq "brief") -or ($format -eq "")) { $c = Get-HPBIOSSettingValue -Name $get -target $target -Verbose:$VerbosePreference }
    else { $c = Get-HPBIOSSetting -Name $get -Format $format -target $target -Verbose:$VerbosePreference }
    return $c
  }

  catch {
    Write-Host -ForegroundColor Magenta "$($PSItem.ToString())"
  }

}

function Do-Export ()
{
  [CmdletBinding()]
  param()
  try {
    [System.IO.Directory]::SetCurrentDirectory($PWD)
    $fullPath = [IO.Path]::GetFullPath($export)

    $supported = @("bcu","xml","json","csv")
    if ($supported -notcontains $format) {
      $format = (Split-Path -Path $fullPath -Leaf).Split(".")[1]

      if ($supported -notcontains $format) {
        $format = "bcu"
      }
    }

    if ($format -eq "bcu") {
      Get-HPBIOSSettingsList -Format $format -target $target -Verbose:$VerbosePreference | Format-Utf8 $fullPath
    }
    else {
      $c = Get-HPBIOSSettingsList -Format $format -target $target -Verbose:$VerbosePreference | Out-File $fullPath
    }
  }
  catch {
    Write-Host -ForegroundColor Magenta "$($PSItem.ToString())"
  }
}

## utf-8 is required by BCU (no bom)
function Format-Utf8 {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory,Position = 0)] [string]$path,
    [switch]$Append,
    [Parameter(ValueFromPipeline)] $InputObject
  )
  [System.IO.Directory]::SetCurrentDirectory($PWD)

  $fullPath = [IO.Path]::GetFullPath($path)
  $stream = $null

  try {
    $stream = New-Object IO.StreamWriter $fullPath
  }
  catch {
    throw $($PSItem.Exception.innerException.Message)
  }

  [System.IO.StreamWriter]$sw = [System.Console]::OpenStandardOutput()
  $sw.AutoFlush = $true
  $htOutStringArgs = @{}
  try {
    $Input | Out-String -Stream @htOutStringArgs | ForEach-Object { $stream.WriteLine($_) }
  } finally {
    $stream.Dispose()
  }
}

function Do-Import ()
{
  [CmdletBinding()]
  param()

  $errorhandling = 1
  if ($nowarnings -eq $true) {
    $errorhandling = 2
  }

  #try {
  [System.IO.Directory]::SetCurrentDirectory($PWD)
  $fullPath = [IO.Path]::GetFullPath($import)

  $supported = @("bcu","xml","json","csv")
  if ($supported -notcontains $format) {
    $format = (Split-Path -Path $fullPath -Leaf).Split(".")[1]

    if ($supported -notcontains $format) {
      $format = "bcu"
    }
  }

  return Set-HPBIOSSettingValuesFromFile -File $fullPath -Format $format -password $currentpassword $nosummary $errorhandling -target $target -Verbose:$VerbosePreference
}

# determine the command set requested
switch ($true)
{
  { $_ -eq $password } {
    Do-Password
    return
  }

  { $_ -eq $export } {
    Do-Export
    return
  }

  { $_ -eq $import } {
    Do-Import
    return
  }
  { $_ -eq $get } {
    Do-Get
    return
  }

  { $_ -eq $reset } {
    Do-Reset
    return
  }

  { $_ -eq $set } {
    Do-Set
    return
  }

  { $_ -eq $help } {
    do-help
    return
  }
  default {
    do-help
    return
  }
}





# SIG # Begin signature block
# MIIcOAYJKoZIhvcNAQcCoIIcKTCCHCUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBGX8S4fvQbNYl/
# Cg+jlOuKqCwDAqPoDiL/0mkhwfHKIqCCCo0wggU2MIIEHqADAgECAhAM1s71mz4i
# 3j/UnuaI4vzeMA0GCSqGSIb3DQEBCwUAMHYxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xNTAzBgNV
# BAMTLERpZ2lDZXJ0IFNIQTIgSGlnaCBBc3N1cmFuY2UgQ29kZSBTaWduaW5nIENB
# MB4XDTE5MDQyMjAwMDAwMFoXDTIwMDQyOTEyMDAwMFowdTELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCkNhbGlmb3JuaWExEjAQBgNVBAcTCVBhbG8gQWx0bzEQMA4GA1UE
# ChMHSFAgSW5jLjEZMBcGA1UECxMQSFAgQ3liZXJzZWN1cml0eTEQMA4GA1UEAxMH
# SFAgSW5jLjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANEwuTFpw7fQ
# 3Ds5fvexal46Gg9TNMvdiJu7qMqDZnDJNl7ECdEPyLxsioGS7/yomOS9RXdXMJOm
# tyV4/wIPbBaGC8E2tbLTbQQ4IJbgvC+Vc46vbo+sI8YTG6qBICOovFw9VhUNXXEy
# SwHMoBNk8JS8R1slPpJKmNGB10HSatMGaHja0Lbqos0QuEx/tx2OXe+mzepIo66T
# dtSv2MfPy2tcVcXIdiJGn7f4otxoj6T9X7hVIl78r5Y2XWHYtDK8KaV1E/qkiNXK
# 1Xw5S53zv2VsZl6i1LZwt3d1Q9pUmm1AZe2YdhSGvwMP2LYBJGXIBbyLYnxS4HKB
# R7MYZyz7H2kCAwEAAaOCAb8wggG7MB8GA1UdIwQYMBaAFGedDyAJDMyKOuWCRnJi
# /PHMkOVAMB0GA1UdDgQWBBSnSAWgK15kcBLxsg4XNsT7ncH29zAOBgNVHQ8BAf8E
# BAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwbQYDVR0fBGYwZDAwoC6gLIYqaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL3NoYTItaGEtY3MtZzEuY3JsMDCgLqAshipo
# dHRwOi8vY3JsNC5kaWdpY2VydC5jb20vc2hhMi1oYS1jcy1nMS5jcmwwTAYDVR0g
# BEUwQzA3BglghkgBhv1sAwswKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGln
# aWNlcnQuY29tL0NQUzAIBgZngQwBBAEwgYgGCCsGAQUFBwEBBHwwejAkBggrBgEF
# BQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFIGCCsGAQUFBzAChkZodHRw
# Oi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEySGlnaEFzc3VyYW5j
# ZUNvZGVTaWduaW5nQ0EuY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQAD
# ggEBAJQblkFw+UYKYSY2M/CIEpJxZDnf+cDhodKAy+goI3XfExRHhyLu3Gc2ibFB
# Y4wyz/sJSfHehtNPYckXxR9k/FB/GfYtEACug9xXxJ+iLxWUNQ4KPt3bXY/kmDxW
# D1QXJFLbW5Dop3w/K0DL3fxnjOfYCcxsYodbeEiCJprCdNi3zd6x/J8Y35GDbLA5
# p7RfIAzKrmBLPHFGDWr/jWTfwPfUNz6jYJ51m0Ba9j81kzpxNUD0yBIZXBkVvSkx
# A09KxzMSSvxvV9DSqSezQBVgWnl9TbElouYUQwk64i0GzL4lTsphK4rQJJ2uuKtH
# wN4E0ibpm0uIqbLhgk+3ic8fHTIwggVPMIIEN6ADAgECAhALfhCQPDhJD/ovZ5qH
# oae5MA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdp
# Q2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNVBAMTIkRp
# Z2lDZXJ0IEhpZ2ggQXNzdXJhbmNlIEVWIFJvb3QgQ0EwHhcNMTMxMDIyMTIwMDAw
# WhcNMjgxMDIyMTIwMDAwWjB2MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNl
# cnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTUwMwYDVQQDEyxEaWdp
# Q2VydCBTSEEyIEhpZ2ggQXNzdXJhbmNlIENvZGUgU2lnbmluZyBDQTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALRKXn0HD0HexPV2Fja9cf/PP09zS5zR
# Df5Ky1dYXoUW3QIVVJnwjzwvTQJ4EGjI2DVLP8H3Z86YHK4zuS0dpApUk8SFot81
# sfXxPKezNPtdSMlGyWJEvEiZ6yhJU8M9j8AO3jWY6WJR3z1rQGHuBEHaz6dcVpbR
# +Uy3RISHmGnlgrkT5lW/yJJwkgoxb3+LMqvPa1qfYsQ+7r7tWaRTfwvxUoiKewpn
# JMuQzezSTTRMsOG1n5zG9m8szebKU3QBn2c13jhJLc7tOUSCGXlOGrK1+7t48Elm
# p8/6XJZ1kosactn/UJJTzD7CQzIJGoYTaTz7gTIzMmR1cygmHQgwOwcCAwEAAaOC
# AeEwggHdMBIGA1UdEwEB/wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMDMH8GCCsGAQUFBwEBBHMwcTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEkGCCsGAQUFBzAChj1odHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJhbmNlRVZSb290Q0EuY3J0
# MIGPBgNVHR8EgYcwgYQwQKA+oDyGOmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydEhpZ2hBc3N1cmFuY2VFVlJvb3RDQS5jcmwwQKA+oDyGOmh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEhpZ2hBc3N1cmFuY2VFVlJvb3RDQS5j
# cmwwTwYDVR0gBEgwRjA4BgpghkgBhv1sAAIEMCowKAYIKwYBBQUHAgEWHGh0dHBz
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCgYIYIZIAYb9bAMwHQYDVR0OBBYEFGed
# DyAJDMyKOuWCRnJi/PHMkOVAMB8GA1UdIwQYMBaAFLE+w2kD+L9HAdSYJhoIAu9j
# ZCvDMA0GCSqGSIb3DQEBCwUAA4IBAQBqDv9+E3wGpUvALoz5U2QJ4rpYkTBQ7Myf
# 4dOoL0hGNhgp0HgoX5hWQA8eur2xO4dc3FvYIA3tGhZN1REkIUvxJ2mQE+sRoQHa
# /bVOeVl1vTgqasP2jkEriqKL1yxRUdmcoMjjTrpsqEfSTtFoH4wCVzuzKWqOaiAq
# ufIAYmS6yOkA+cyk1LqaNdivLGVsFnxYId5KMND66yRdBsmdFretSkXTJeIM8ECq
# XE2sfs0Ggrl2RmkI2DK2gv7jqVg0QxuOZ2eXP2gxFjY4lT6H98fDr516dxnZ3pO1
# /W4r/JT5PbdMEjUsML7ojZ4FcJpIE/SM1ucerDjnqPOtDLd67GftMYIRATCCEP0C
# AQEwgYowdjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTE1MDMGA1UEAxMsRGlnaUNlcnQgU0hBMiBI
# aWdoIEFzc3VyYW5jZSBDb2RlIFNpZ25pbmcgQ0ECEAzWzvWbPiLeP9Se5oji/N4w
# DQYJYIZIAWUDBAIBBQCgfDAQBgorBgEEAYI3AgEMMQIwADAZBgkqhkiG9w0BCQMx
# DAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkq
# hkiG9w0BCQQxIgQgYKHfPJry/75E4nF0X4CpovGLWdxcdhmZ6579NF9CNkwwDQYJ
# KoZIhvcNAQEBBQAEggEAh381994drkBkfVAV12V2I7aaQJu2U+dZ7zIPUkFh4VRM
# ActMn6giHn1WBmF/oXOFQb/+1LTb5X9qTs+oCrh+hq+Abk5hCQsgAmzbBHL7tTpy
# uRBjCIEf2JWkEUEdIH7W6aTpO9c47fKhr/yAI2kgic7ZxCULyOhryQs8Ov7AiQCC
# kaJN5RKkiB+/Rdecv3lJU0w9dJFzmAshpXawR2cVcmq10PUZDvODpnyeufG2ErE4
# 3Za/dw9Mnm8knrLfBz72NNQiN1OJ41IUsbICBZ5UpsX6wqsCFFq/gYCSB/V5Q2nm
# 47FUT9pgkx8wIqT1w06TJPUlIeHVjlMGrAoA2jOL0qGCDskwgg7FBgorBgEEAYI3
# AwMBMYIOtTCCDrEGCSqGSIb3DQEHAqCCDqIwgg6eAgEDMQ8wDQYJYIZIAWUDBAIB
# BQAweAYLKoZIhvcNAQkQAQSgaQRnMGUCAQEGCWCGSAGG/WwHATAxMA0GCWCGSAFl
# AwQCAQUABCBgVaBi1QC6BgzdrFoD8GZvf9rWUhIvnhfU6aWGb3VnugIRANgmkm/O
# Opmx7BKYdi1ZTrkYDzIwMTkxMTA1MTY0NTM2WqCCC7swggaCMIIFaqADAgECAhAE
# zT+FaK52xhuw/nFgzKdtMA0GCSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUw
# EwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20x
# MTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3RhbXBpbmcg
# Q0EwHhcNMTkxMDAxMDAwMDAwWhcNMzAxMDE3MDAwMDAwWjBMMQswCQYDVQQGEwJV
# UzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xJDAiBgNVBAMTG1RJTUVTVEFNUC1T
# SEEyNTYtMjAxOS0xMC0xNTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEB
# AOlkNZz6qZhlZBvkF9y4KTbMZwlYhU0w4Mn/5Ts8EShQrwcx4l0JGML2iYxpCAQj
# 4HctnRXluOihao7/1K7Sehbv+EG1HTl1wc8vp6xFfpRtrAMBmTxiPn56/UWXMbT6
# t9lCPqdVm99aT1gCqDJpIhO+i4Itxpira5u0yfJlEQx0DbLwCJZ0xOiySKKhFKX4
# +uGJcEQ7je/7pPTDub0ULOsMKCclgKsQSxYSYAtpIoxOzcbVsmVZIeB8LBKNcA6P
# isrg09ezOXdQ0EIsLnrOnGd6OHdUQP9PlQQg1OvIzocUCP4dgN3Q5yt46r8fcMbu
# QhZTNkWbUxlJYp16ApuVFKMCAwEAAaOCAzgwggM0MA4GA1UdDwEB/wQEAwIHgDAM
# BgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0gBIIB
# tjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxodHRwczovL3d3
# dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4AeQAg
# AHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQAZQAg
# AGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUAIABv
# AGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAAYQBu
# AGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcAcgBl
# AGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBs
# AGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBk
# ACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsGCWCG
# SAGG/WwDFTAfBgNVHSMEGDAWgBT0tuEgHf4prtLkYaWyoiWyyBc1bjAdBgNVHQ4E
# FgQUVlMPwcYHp03X2G5XcoBQTOTsnsEwcQYDVR0fBGowaDAyoDCgLoYsaHR0cDov
# L2NybDMuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC10cy5jcmwwMqAwoC6GLGh0
# dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQtdHMuY3JsMIGFBggr
# BgEFBQcBAQR5MHcwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBPBggrBgEFBQcwAoZDaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0U0hBMkFzc3VyZWRJRFRpbWVzdGFtcGluZ0NBLmNydDANBgkqhkiG9w0BAQsF
# AAOCAQEALoOhRAVKBOO5MlL62YHwGrv4CY0juT3YkqHmRhxKL256PGNuNxejGr9Y
# I7JDnJSDTjkJsCzox+HizO3LeWvO3iMBR+2VVIHggHsSsa8Chqk6c2r++J/BjdEh
# jOQpgsOKC2AAAp0fR8SftApoU39aEKb4Iub4U5IxX9iCgy1tE0Kug8EQTqQk9Eec
# 3g8icndcf0/pOZgrV5JE1+9uk9lDxwQzY1E3Vp5HBBHDo1hUIdjijlbXST9X/Aqf
# I1579JSN3Z0au996KqbSRaZVDI/2TIryls+JRtwxspGQo18zMGBV9fxrMKyh7eRH
# TjOeZ2ootU3C7VuXgvjLqQhsUwm09zCCBTEwggQZoAMCAQICEAqhJdbWMht+QeQF
# 2jaXwhUwDQYJKoZIhvcNAQELBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMb
# RGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTE2MDEwNzEyMDAwMFoXDTMx
# MDEwNzEyMDAwMFowcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQg
# U0hBMiBBc3N1cmVkIElEIFRpbWVzdGFtcGluZyBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAL3QMu5LzY9/3am6gpnFOVQoV7YjSsQOB0UzURB90Pl9
# TWh+57ag9I2ziOSXv2MhkJi/E7xX08PhfgjWahQAOPcuHjvuzKb2Mln+X2U/4Jvr
# 40ZHBhpVfgsnfsCi9aDg3iI/Dv9+lfvzo7oiPhisEeTwmQNtO4V8CdPuXciaC1Tj
# qAlxa+DPIhAPdc9xck4Krd9AOly3UeGheRTGTSQjMF287DxgaqwvB8z98OpH2YhQ
# Xv1mblZhJymJhFHmgudGUP2UKiyn5HU+upgPhH+fMRTWrdXyZMt7HgXQhBlyF/EX
# Bu89zdZN7wZC/aJTKk+FHcQdPK/P2qwQ9d2srOlW/5MCAwEAAaOCAc4wggHKMB0G
# A1UdDgQWBBT0tuEgHf4prtLkYaWyoiWyyBc1bjAfBgNVHSMEGDAWgBRF66Kv9JLL
# gjEtUYunpyGd823IDzASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIB
# hjATBgNVHSUEDDAKBggrBgEFBQcDCDB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUH
# MAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDov
# L2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNy
# dDCBgQYDVR0fBHoweDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBQBgNVHSAESTBH
# MDgGCmCGSAGG/WwAAgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNl
# cnQuY29tL0NQUzALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggEBAHGVEulR
# h1Zpze/d2nyqY3qzeM8GN0CE70uEv8rPAwL9xafDDiBCLK938ysfDCFaKrcFNB1q
# rpn4J6JmvwmqYN92pDqTD/iy0dh8GWLoXoIlHsS6HHssIeLWWywUNUMEaLLbdQLg
# cseY1jxk5R9IEBhfiThhTWJGJIdjjJFSLK8pieV4H9YLFKWA1xJHcLN11ZOFk362
# kmf7U2GJqPVrlsD0WGkNfMgBsbkodbeZY4UijGHKeZR+WfyMD+NvtQEmtmyl7odR
# IeRYYJu6DC0rbaLEfrvEJStHAgh8Sa4TtuF8QkIoxhhWz0E0tmZdtnR79VYzIi8i
# NrJLokqV2PWmjlIxggJNMIICSQIBATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UE
# ChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYD
# VQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBAhAE
# zT+FaK52xhuw/nFgzKdtMA0GCWCGSAFlAwQCAQUAoIGYMBoGCSqGSIb3DQEJAzEN
# BgsqhkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMTkxMTA1MTY0NTM2WjArBgsq
# hkiG9w0BCRACDDEcMBowGDAWBBQDJb1QXtqWMC3CL0+gHkwovig0xTAvBgkqhkiG
# 9w0BCQQxIgQg0+hO3z3kY8QGqUKBcPePvvX+q6NeZNcEVDkNDr1xGxEwDQYJKoZI
# hvcNAQEBBQAEggEAMp1wnlMzQx6RpUl+sBJRqCAc+/JKiOuz1pBmmkPExY6pzq7I
# VtKlK+f7e+ry7GBpp7zI5E0HUsBnUJmsxhgCo6b/AeIEgZT9jsCcb4rphVCpFbpF
# QjuBXFJX8h8Vvv55Og3qpw9jsLp18XhreB3kvdpjzIGU0xOOIS3yztUVOFHfyLzF
# RDei2v4T8fevkrhrFXDuJdmDkQO0CVvDCdsKetxYpy2xgSOW/2ylsoLsKHG6klIx
# T+f70BBBFNoBhen7D9qqlez2ySYj3KLveVrrcV2Rt+ay7A0ZMpGSqeGj4Nm7G913
# y9Qr8TYfx99HtlTLOvBTIS+D/hNE8iP5qXEfIw==
# SIG # End signature block
